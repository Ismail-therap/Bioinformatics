####################################################
## Visualize gene expression data:Brest cancer data 
## Sample size: 60
## Data source: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE183947
#############################################################################





# Loading the data
dat <- read.csv("GSE183947_fpkm.csv")
dim(dat)

# Get metadata
gse <- getGEO(GEO = 'GSE183947',GSEMatrix = TRUE)
metadata <- pData(phenoData(gse[[1]]))
metadata.subset <- select(metadata,c(1,10,11,17))

metadata.modified <- metadata %>%
  select(1,10,11,17) %>%
  rename(tissue = characteristics_ch1) %>%
  rename(metastasis = characteristics_ch1.1) %>%
  mutate(tissue = gsub('tissue: ',"",tissue)) %>%
  mutate(metastasis = gsub('metastasis: ',"",metastasis))


head(metadata.modified)
head(dat)

# Reshaping data
dat.long <- dat %>%
            rename(gene = X) %>%
            gather(key = 'samples',value = 'FPKM',-gene)


# Join dat.long and subsetted metadata

dat.long <- dat.long %>%
              left_join(.,metadata.modified,by = c('samples' = 'description'))


# Explore data
dat.long %>%
  filter(gene == 'BRCA1'|gene == 'BRCA2') %>%
  group_by(gene,tissue) %>%
  summarize(mean_FPKM = mean(FPKM),median_FPKM = median(FPKM)) %>%
  arrange(mean_FPKM)
